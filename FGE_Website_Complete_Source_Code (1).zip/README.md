# Flying Group Enterprises Website

This is the complete source package for the Flying Group Enterprises website.

## Architecture

The website is currently a static, responsive website. It does not use a server-side backend, database, CMS, or API.

- `dist/index.html` — website content and page structure
- `dist/styles.css` — responsive layout, colours, typography and visual styling
- `dist/script.js` — mobile navigation, header behaviour and copyright year
- `dist/assets/` — logo and service images
- `.openai/hosting.json` — hosting configuration for the deployed ChatGPT Site

## Run locally

Open `dist/index.html` directly in a browser, or serve the `dist` folder with any static web server.

Example with Python:

```bash
python3 -m http.server 8080 --directory dist
```

Then open `http://localhost:8080`.

## Email and contact links

The website currently links to:

- `enquiries@flyinggroupenterprises.co.in`
- WhatsApp: `+91 70425 09888`

The domain email must be activated separately through the selected email provider and DNS configuration.

## Adding a backend later

A backend would be required for features such as a database-powered enquiry form, admin dashboard, client login, quotation management, file uploads, or automated email notifications.
